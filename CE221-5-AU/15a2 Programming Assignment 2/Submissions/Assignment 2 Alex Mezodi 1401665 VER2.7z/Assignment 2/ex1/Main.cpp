/**
* Main.cpp file to test Student
*/
#include "Student.h"
using namespace std;
#include <iostream>
#include <string>
#include <fstream>
#include <list>
#include <stdlib.h>
#include <algorithm>


void func1 (list<Student> studList, float mark) {
	typedef list<Student>::iterator it_type;
	for(it_type iterator = studList.begin(); iterator != studList.end(); iterator++) {
		if(iterator->hasMark(mark)) cout << *iterator;	
	}
}

void func2 (list<Student> studList, string module, float mark){
	typedef list<Student>::iterator it_type;
	for(it_type iterator = studList.begin(); iterator != studList.end(); iterator++) {
		if(iterator->hasEqualMark(mark)) 
			if(iterator -> getMark(module) == 0) cout << "";
			else {
			cout << "Name: " << iterator -> getName();
			cout << " Mark for Module:  " << iterator -> getMark(module) << endl;}
	}
}

int main()
{
	list<Student> studList;
	typedef list<Student>::iterator it_type;
	
	ifstream studFile;
	ifstream marksFile;
	
	cout << "Please enter [STUDENTS] file:" << endl;
	//ifstream studFile("studs.txt");
	char studFileName[30];
	cin >> studFileName; 
	studFile.open(studFileName);
	string line;
	
	while (getline(studFile, line)){
		string regStr = line.substr(0,5);
		int regNo = atoi(regStr.c_str()); //CONVERT reg number to int
		string nameStr = line.substr(6,-1);
		
		Student pupil = Student(nameStr, regNo);
		studList.push_back(pupil);
		//cout << pupil;
	
	
	}

	
	
	cout << "Please enter [MARKS] file:" << endl;
	char marksFileName[30];
	//ifstream marksFile("marks.txt");
	cin >> marksFileName; 
	marksFile.open(marksFileName);
	
	while(getline(marksFile, line)){
		string regStr = line.substr(0,5);
		int regNo = atoi(regStr.c_str()); //CONVERT reg number to int
		
		string module = line.substr(6,5);
		
		string markStr = line.substr(12,-1);
		double markInt = atof(markStr.c_str()); //CONVERT mark to double
		
	
		for(it_type iterator = studList.begin(); iterator != studList.end(); iterator++) {
			//cout << iterator->getName() << endl;
			if(iterator->getRegNo() == regNo) iterator->addMark(module,markInt);
		}
	}
	
	for(it_type iterator = studList.begin(); iterator != studList.end(); iterator++) {
	 	cout << "Name: " << iterator->getName() << endl;
	 	cout << "Reg. Number: " << iterator -> getRegNo() << endl;
	 	iterator -> getMap();
	 	cout << endl;
 	}
 	string inputString("");
 	while(inputString != "x") {
 		cout << "Please enter one of the following menu options: " << endl;
 		cout << " '1' to test function1. '2' to test function2. or 'x' to quit..:" << endl;
 		cin >> inputString;
 		if(inputString == "1") {
 			string markStr("");
 			double mark;
 			cout << "Please enter the minimum mark requirement: ";
 			cin >> markStr;
 			mark = atof(markStr.c_str());
 			func1(studList, mark);
 		}
 		if(inputString == "2") {
 			string markStr("");
 			double mark;
 			cout << "Please enter the minimum mark requirement: ";
 			cin >> markStr;
 			mark = atof(markStr.c_str());
 			string module("");
			cout << "Please enter the module (like CE151): ";
 			cin >> module;
 			func2(studList, module, mark);	
 		}
 	}
 	exit(1);
}