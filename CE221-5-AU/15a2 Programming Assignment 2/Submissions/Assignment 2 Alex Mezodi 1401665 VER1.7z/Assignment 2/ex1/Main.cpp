/**
* Main.cpp file to test Student
*/
#include "Student.h"
using namespace std;
#include <iostream>
#include <string>
#include <fstream>
#include <list>
#include <stdlib.h>
#include <algorithm>

void func1 (list<Student> studList, float mark) {
	typedef list<Student>::iterator it_type;
	for(it_type iterator = studList.begin(); iterator != studList.end(); iterator++) {
		if(iterator->hasMark(mark)) cout << *iterator;	
	}
}

void func2 (list<Student> studList, string module, float mark){
	
}

int main()
{
	list<Student> studList;
	typedef list<Student>::iterator it_type;
	
	cout << "Please enter [STUDENTS] file:" << endl;
	ifstream studFile("studs.txt");
	//cin >> studFile; 
	string line;
	
	while (getline(studFile, line)){
		string regStr = line.substr(0,5);
		int regNo = atoi(regStr.c_str()); //CONVERT reg number to int
		string nameStr = line.substr(6,-1);
		
		Student pupil = Student(nameStr, regNo);
		studList.push_back(pupil);
		//cout << pupil;
	
	
	}
	//cout << "studList has: " << studList.size() << " students.\n";
	
	
	cout << "Please enter [MARKS] file:" << endl;
	ifstream marksFile("marks.txt");
	//cin >> marksFile; 
	
	while(getline(marksFile, line)){
		string regStr = line.substr(0,5);
		int regNo = atoi(regStr.c_str()); //CONVERT reg number to int
		
		string module = line.substr(6,5);
		
		string markStr = line.substr(12,-1);
		double markInt = atof(markStr.c_str()); //CONVERT mark to int
		
		//map<string, float>::iterator it = studList.find(regNo);
		for(it_type iterator = studList.begin(); iterator != studList.end(); iterator++) {
			//cout << iterator->getName() << endl;
			if(iterator->getRegNo() == regNo) iterator->addMark(module,markInt);
		}
	}
	
	for(it_type iterator = studList.begin(); iterator != studList.end(); iterator++) {
	 	cout << "Name: " << iterator->getName() << endl;
	 	cout << "Reg. Number: " << iterator -> getRegNo() << endl;
	 	//cout << iterator -> getMark("CE151") << endl;
	 	iterator -> getMap();
	 	//cout <<""<< iterator -> returnMap();
	 	//cout << iterator -> returnMark();
	 	//cout << *iterator;
	 	//cout << iterator->hasMark(30);
	 	cout << endl;
 	}
 	cout << "------------------------------------------------------------------" << endl;
 	func1(studList, 40);
	//cout << studList.front();	
}