/**
*Student.cpp student functions
*/

#include "Student.h"
using namespace std;
#include <iostream>

Student::Student(const string &name, int regNo):Person(name){
	this -> regNo = regNo;
	this -> marks;
	//cout << regNo << " " << name << endl
}
int Student::getRegNo() const 
{
	return regNo;
}
void Student::addMark(const string& module, float mark) 
{
	map<string,float>::iterator it = marks.find(module);
	if(it == marks.end()) marks.insert(make_pair(module,mark));
	else it -> second = mark; 
	
	/*
	typedef map<string,float>::const_iterator MapIterator;
	for(MapIterator iter = marks.begin(); iter != marks.end(); iter++){
		cout << "Mark: " << iter->second << endl;
	}*/
	
}
float Student::getMark(const string &module) const throw (NoMarkException) 
{
	NoMarkException myex;
	try {
		map<string,float>::const_iterator it = marks.find(module);
		if(it == marks.end()) throw myex;
		else return it->second;
	} catch (NoMarkException myex){
		cout << "No marks present for student. Returning ";
		return 0;
	}
}
void Student::getMap() {
	typedef map<string,float>::const_iterator MapIterator;
	for(MapIterator iter = marks.begin(); iter != marks.end(); iter++){
		cout << "Module: " << iter -> first << " ";
		cout << "Mark: " << iter->second << endl;
	}
}
list<float> Student::returnMark() const {
	list<float> markList;
	typedef map<string,float>::const_iterator MapIterator;
	for(MapIterator iter = marks.begin(); iter != marks.end(); iter++){
		markList.push_back(iter->second);
	}	
	return markList; //markList correctly returns a list of marks ie.: 67.2, 68.3, 55.5
	
}
map<string, float> Student::returnMap() const{
	return marks;
}

bool Student::hasMark(float mark) const throw (NoMarkException){
	NoMarkException myex;
	try {
		if(marks.empty()) throw myex;
		else {
			typedef map<string,float>::const_iterator MapIterator;
			for(MapIterator iter = marks.begin(); iter != marks.end(); iter++){
				if(iter->second > mark) return true;
			}
			return false;
		
		}
	} catch (NoMarkException myex){
		return false;
	} 
}

float Student::MinMark() const throw (NoMarkException) {
	float min;
	NoMarkException myex;

	try {
		if(marks.empty()) throw myex;
		else {
			typedef map<string,float>::const_iterator MapIterator;
			min = marks.begin()->second;
			for(MapIterator iter = marks.begin(); iter != marks.end(); iter++){
				if(min > iter->second) min = iter -> second;
			}
			return min;
		
		}
	} catch (NoMarkException myex){
		cout << "No marks present for student. Returning ";
		return 0;
	}  
}

float Student::MaxMark() const throw (NoMarkException){
	float max;
	NoMarkException myex;

	try {
		if(marks.empty()) throw myex;
		else {
			typedef map<string,float>::const_iterator MapIterator;
			max = marks.begin()->second;
			for(MapIterator iter = marks.begin(); iter != marks.end(); iter++){
				if(max < iter->second) max = iter -> second;
			}
			return max;
		
		}
	} catch (NoMarkException myex){
		cout << "No marks present for student. Returning ";
		return 0;
	} 	    
}

float Student::AveMark() const throw (NoMarkException){
	float ave;
	int count = 0;
	NoMarkException myex;

	try {
		if(marks.empty()) throw myex;
		else {
			typedef map<string,float>::const_iterator MapIterator;
			for(MapIterator iter = marks.begin(); iter != marks.end(); iter++){
				ave = ave + iter -> second;
				count++;
			}
			ave = ave / count;
			return ave;
		
		}
	} catch (NoMarkException myex){
		cout << "No marks present for student. Returning ";
		return 0;
	}    
}

ostream& operator<<(ostream &str, const Student &s){
	str << endl;
	str << "Name: ";
	str << s.getName();
	str << " RegNo: ";
	str << s.getRegNo();
	str << " Min. Mark: ";
	str << s.MinMark();
	str << " Max. Mark: ";
	str << s.MaxMark();
	str << " Ave. Mark: ";
	str << s.AveMark();
	return str;
	
}