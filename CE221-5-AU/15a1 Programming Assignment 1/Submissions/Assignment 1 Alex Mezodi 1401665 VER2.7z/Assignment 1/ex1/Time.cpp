using namespace std;

#include <iostream>
#include <iomanip>
#include "Time.h"

Time::Time()
{ hour = min = sec = 0;
}

Time::Time(int h, int m, int s)
{ setTime(h, m, s);
}

void Time::setTime(int h, int m, int s)
{ hour = (h>=0 && h<24) ? h : 0;
  min = (m>=0 && m<60) ? m : 0;
  sec = (s>=0 && s<60) ? s : 0;
}

Time& Time::operator+=(unsigned int n)
{ sec += n;
  if (sec >= 60)
  { min += sec/60;
    sec %= 60;
    if (min >=60)
    { hour = (hour + min/60) % 24;
      min %= 60;
    }
  }
  return *this;
}

Time Time::operator+(unsigned int n) const
{ Time tCopy(*this);
  tCopy += n;
  return tCopy;
}

Time& Time::operator++()        // prefix version
{ *this += 1;
  return *this;
}

Time Time::operator++(int n)    // postfix version
{ Time tCopy(*this);
  *this += 1;
  return tCopy;
}

ostream& operator<<(ostream &o, const Time &t)
{ o << setfill('0') << setw(2) <<  t.hour << ':' << setw(2) << t.min << ':' << setw(2) << t.sec;
  return o;
}
/*----------------------------MY NEW FUNCTIONS :)---------------------------*/
Time& Time::operator-=(unsigned int n)
{ sec -= n;
  if (sec <= 60)
  { min -= sec/60;
    sec %= 60;
    if (min <=60)
    { hour = (hour - min/60) % 24;
      min %= 60;
    }
  }
  return *this;
}
//decrement time by 1 second
Time Time::operator-(unsigned int n) const
{ Time tCopy(*this);
  tCopy -= n;
  return tCopy;
}
//check if 2 times are equal
bool Time::operator==(const Time &t) const {
	Time tCopy(*this);
	if(t.hour == tCopy.hour){
		if(t.min == tCopy.min) {
			if(t.sec == tCopy.sec) {
				return true;
			}
		}
	}
	return false;
}
//check if 2 times are not equal
bool Time::operator!=(const Time &t) const {
	Time tCopy(*this);
	if(t==tCopy){
		return false;
	}
	return true;
}
//check if a time is before another time
bool Time::operator<(const Time &t) const {
	Time tCopy(*this);
	if(t.hour > tCopy.hour){
		return true;
	}
	else if (t.hour == tCopy.hour) {
		if(t.min > tCopy.min) {
			return true;
		}
		else if(t.min == tCopy.min) {
			if(t.sec > tCopy.sec){
				return true;
			}
		}
	}	
	return false;
}
//check if a time is before or at the same time as another time
bool Time::operator<=(const Time &t) const {
	Time tCopy(*this);
	if(tCopy < t || t == tCopy) {
		return true;
	}
	return false;
}
//decrement time by 1 second
Time& operator--(Time &t) {
	t -= 1;
  	return t;
}
Time operator--(Time &t, int n){
	Time tCopy(t);
	t -= 1;
  	return tCopy;
}
//check if a time is after another time or not
bool operator>(const Time &t, const Time &k){
	if(t<k || t==k) {
		return false;
	}
	return true;
}
//check if a time is after another time or at the same time or not
bool operator>=(const Time &t, const Time &k){
	if(k < t || t == k) {
		return true;
	}
	return false;	
}
//check the difference between 2 times
unsigned int operator-(const Time &t, const Time &k) {
	int tInt = t.hour*3600 + t.min*60 + t.sec; //convert all values to seconds
	int kInt = k.hour*3600 + k.min*60 + k.sec;
	int answer = tInt - kInt; //get the answer in seconds format
	if(t < k) {
		answer = answer * -1; //sometimes we get a negative answer, in that case absolute the value
		answer = (24*3600)-answer; 
	}
	if(answer % 60 >= 30) { //if the difference is over 30 seconds add another minute to it (rounding up)
		answer = answer + 60;
	}
	answer = answer / 60; //for minutes version
	return  answer;
}
