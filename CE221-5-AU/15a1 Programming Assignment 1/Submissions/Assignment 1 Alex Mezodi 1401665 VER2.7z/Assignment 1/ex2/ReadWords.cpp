/**
* ReadWords Functions
*/
#include<iostream>
#include "ReadWords.h"
#include <stdlib.h>
#include <algorithm>


using namespace std;


ReadWords::ReadWords(const char *filename)
{
	wordfile.open(filename);
	if (!wordfile) {   
		cout << "could not open " << filename << endl; //close if file couldn't be opened
		exit(1);
		
	}
}
void ReadWords::close() {
	wordfile.close();
}
//get the next word in file
//then make it lowercase
//then remove punctuation marks at the beginning and end
string ReadWords::getNextWord(){
	string word; //saving each word into string
	wordfile >> word;
	transform(word.begin(), word.end(), word.begin(), ::tolower);
		while(ispunct(word[word.size()-1])) word = word.substr(0,word.size()-1); 
		while(ispunct(word[0])) word = word.substr(1,word.length());
	return word;
}
//checks if file ends
bool ReadWords::isNextWord(){
	return !wordfile.eof();
}
