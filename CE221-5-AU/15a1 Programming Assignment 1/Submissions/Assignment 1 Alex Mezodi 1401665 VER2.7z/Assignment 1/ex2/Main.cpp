/**
 * Main function
 */
 #include <iostream>
 #include"ReadWords.h"
 #include"Writer.h"
 #include <map>
 
 using namespace std;
 
 int main()
 {
 	int counter = 0; //for counting the total words
 	map<string, unsigned int> wordsCount; //used a map for key: value
 	typedef map<string, unsigned int>::iterator it_type; //iterator for getting through the map easily
	
 	cout << "Hello. Please enter the filename of the [SCRIPT]: ";
	char filename[30];
	cin >> filename; //get the script file
	
	cout << "Now, please enter the filename for the [SEARCHWORDS]: ";
	char SRCfilename[30];
	cin >> SRCfilename; //get the testwords from user
	
	
	cout << "Please enter a filename for the [OUTPUT]: ";
	char outFilename[30];
	cin >> outFilename; //name of the file to be created
	
 	ReadWords readFile(filename); //read the words and call constructor
 	ReadWords readSRCFile(SRCfilename);
 	
 	
 	Writer writeOutput(outFilename);
 	//while there are words in the file
	while(readSRCFile.isNextWord()) {
		string myWord = readSRCFile.getNextWord(); //create a new map key entry and set it to 0
		if (wordsCount.find(myWord) == wordsCount.end()) wordsCount[myWord] = 0;
	}
	
	//while there are words in the script
	while(readFile.isNextWord()) {	
	 	counter++; //add 1 to total words per word
	 	string myWord = readFile.getNextWord(); //read the next word
		if (wordsCount.find(myWord) != wordsCount.end()) wordsCount[myWord]++;
		//and if it appears in the map as a key, add +1 to value
	}
	readFile.close();
	
 	cout << endl << "Number of total words: " << counter << endl;//write to console the total number and map values

 	for(it_type iterator = wordsCount.begin(); iterator != wordsCount.end(); iterator++) {
 		cout << iterator->first << ":";
 		cout << iterator->second << endl;
 	}
 	
 	//write to file the total number and map values
 	for(it_type iterator = wordsCount.begin(); iterator != wordsCount.end(); iterator++) {
		writeOutput.writeString(iterator->first);
		writeOutput.writeChar(':');
	 	writeOutput.writeInt(iterator->second);
		writeOutput.writeEol();
 	}
 	writeOutput.writeString("Number of total words: ");
 	writeOutput.writeInt(counter);
 	readSRCFile.close();
 	writeOutput.close();
 }