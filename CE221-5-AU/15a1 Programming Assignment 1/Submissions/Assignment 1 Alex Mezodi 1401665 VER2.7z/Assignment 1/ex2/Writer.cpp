/*
* Writer.cpp
*/
using namespace std;

#include "Writer.h"
#include <fstream>
#include<stdlib.h>

Writer::Writer(const char *filename)
{
	out.open(filename);
	if (!out) {   
		cout << "could not create " << filename << endl; //if cannot write to file, close
		exit(1);		
	}
}
//close function
void Writer::close() {
	out.close();
}
//intiger writer for total number and counter
void Writer::writeInt(int n)
{
	out << n;
}
//char writer
void Writer::writeChar(char s) 
{
	out << s;
}
//function for writing words
void Writer::writeString(string s)
{
	out << s;
}
//function for newline writing
void Writer::writeEol()
{
	out << "\n";
}