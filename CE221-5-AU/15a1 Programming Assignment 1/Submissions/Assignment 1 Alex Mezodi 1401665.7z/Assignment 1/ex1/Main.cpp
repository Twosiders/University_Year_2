// program to test class Time
#include <iostream>
#include "Time.h"
using namespace std;
int main(){ 
	Time t(2,5,25); //instantiate object t of class Time
	Time p(2,5,35);
	Time k(3,10,0);
	// output t's initial value in both formats
	cout << t << endl;
	cout << p << endl;
	
	bool isTrue = k == p;
	cout << isTrue << endl;
	
	bool isFalse = k != t;
	cout << isFalse << endl;
	
	bool isLessThan = t < k;
	cout << isLessThan << endl;
	
	bool isLessOrEqual = t <= k;
	cout << isLessOrEqual << endl;
	--t;
	cout << t-- << endl;
	cout << t << endl;
	
	bool isBiggerThan = t > k;
	cout << isBiggerThan << endl;
	
	bool isBiggerOrEqual = t >= k;
	cout << isBiggerOrEqual << endl;
	
	int difference = p - k;
	cout << difference << endl;
}	