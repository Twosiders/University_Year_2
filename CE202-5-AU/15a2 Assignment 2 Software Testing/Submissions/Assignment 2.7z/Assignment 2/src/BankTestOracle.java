/*
Oracle tester java file
zo
*/

public	class	BankTestOracle	{
    static int i = 0;
    public	static	boolean	bankAccount(int result){
        int results[] = {70,30,50,100000};
        BankTestDriver.totalTests++;
        if (result == results[i++]){
            return true;
        }
        else {return false;}
    }
}