import java.io.InputStream;
import java.util.InputMismatchException;

public class BankTestDriver {
    static float totalTests = 0;
    /**
     * Main function calculating the POFOD on the basis of the return statement
     * results of all test cases
     * POFOD is being printed out
     */
    public static void main(String[] args) {
        float wrongResult = 0;
        if (!test1()) wrongResult++;
        if (!test2()) wrongResult++;
        if (!test3()) wrongResult++;
        if (!test4()) wrongResult++;
        if (!test5()) wrongResult++;
        if (!test6()) wrongResult++;
        if (!test7()) wrongResult++;
        if (!test8()) wrongResult++;
        if (!test9()) wrongResult++;
        if (!test10()) wrongResult++;
        if (!test11()) wrongResult++;
        if (!test12()) wrongResult++;
        if (!test13()) wrongResult++;
        if (!test14()) wrongResult++;
        if (!test15()) wrongResult++;
        if (!test16()) wrongResult++;
        if (!test17()) wrongResult++;
        if (!test18()) wrongResult++;
        if (!test19()) wrongResult++;
        if (!test20()) wrongResult++;
        if (!test21()) wrongResult++;
        if (!test22()) wrongResult++;
        if (!test23()) wrongResult++;
        if (!test24()) wrongResult++;
        if (!test25()) wrongResult++;
        if (!test26()) wrongResult++;
        if (!test27()) wrongResult++;
        if (!test28()) wrongResult++;
        if (!test29()) wrongResult++;
        if (!test30()) wrongResult++;
        if (!test31()) wrongResult++;
        //test2 etc.
        System.out.println("wrong:"+wrongResult+" total: "+totalTests);
        float pofod = (wrongResult / totalTests);
        System.out.println("POFOD is : "+pofod); //output your POFOD
    }

    /**
     * test case implementations
     * return boolean variables which indicate how successful the cases are
     */
    public static boolean test1() {
        Bank testClass = new Bank();
        int result = testClass.bankAccount(01234, 50);
        return BankTestOracle.bankAccount(result);
    }
    public static boolean test2() {Bank testClass = new Bank();int result = testClass.bankAccount(01234, 50);return BankTestOracle.bankAccount(result);}
    public static boolean test3() {Bank testClass = new Bank();int result = testClass.bankAccount(01234, 50);return BankTestOracle.bankAccount(result);}
    public static boolean test4() {Bank testClass = new Bank();int result = testClass.bankAccount(01234, 50);return BankTestOracle.bankAccount(result);}
    public static boolean test5() {Bank testClass = new Bank();int result = testClass.bankAccount(01234, 50);return BankTestOracle.bankAccount(result);}
    public static boolean test6() {Bank testClass = new Bank();int result = testClass.bankAccount(01234, 50);return BankTestOracle.bankAccount(result);}
    public static boolean test7() {Bank testClass = new Bank();int result = testClass.bankAccount(01234, 50);return BankTestOracle.bankAccount(result);}
    public static boolean test8() {Bank testClass = new Bank();int result = testClass.bankAccount(01234, 50);return BankTestOracle.bankAccount(result);}
    public static boolean test9() {Bank testClass = new Bank();int result = testClass.bankAccount(01234, 50);return BankTestOracle.bankAccount(result);}
    public static boolean test10() {Bank testClass = new Bank();int result = testClass.bankAccount(01234, 50);return BankTestOracle.bankAccount(result);}
    public static boolean test11() {Bank testClass = new Bank();int result = testClass.bankAccount(01234, 50);return BankTestOracle.bankAccount(result);}
    public static boolean test12() {Bank testClass = new Bank();int result = testClass.bankAccount(01234, 50);return BankTestOracle.bankAccount(result);}
    public static boolean test13() {Bank testClass = new Bank();int result = testClass.bankAccount(01234, 50);return BankTestOracle.bankAccount(result);}
    public static boolean test14() {Bank testClass = new Bank();int result = testClass.bankAccount(01234, 50);return BankTestOracle.bankAccount(result);}
    public static boolean test15() {Bank testClass = new Bank();int result = testClass.bankAccount(01234, 50);return BankTestOracle.bankAccount(result);}
    public static boolean test16() {Bank testClass = new Bank();int result = testClass.bankAccount(01234, 50);return BankTestOracle.bankAccount(result);}
    public static boolean test17() {Bank testClass = new Bank();int result = testClass.bankAccount(01234, 50);return BankTestOracle.bankAccount(result);}
    public static boolean test18() {Bank testClass = new Bank();int result = testClass.bankAccount(01234, 50);return BankTestOracle.bankAccount(result);}
    public static boolean test19() {Bank testClass = new Bank();int result = testClass.bankAccount(01234, 50);return BankTestOracle.bankAccount(result);}
    public static boolean test20() {Bank testClass = new Bank();int result = testClass.bankAccount(01234, 50);return BankTestOracle.bankAccount(result);}
    public static boolean test21() {Bank testClass = new Bank();int result = testClass.bankAccount(01234, 50);return BankTestOracle.bankAccount(result);}
    public static boolean test22() {Bank testClass = new Bank();int result = testClass.bankAccount(01234, 50);return BankTestOracle.bankAccount(result);}
    public static boolean test23() {Bank testClass = new Bank();int result = testClass.bankAccount(01234, 50);return BankTestOracle.bankAccount(result);}
    public static boolean test24() {Bank testClass = new Bank();int result = testClass.bankAccount(01234, 50);return BankTestOracle.bankAccount(result);}
    public static boolean test25() {Bank testClass = new Bank();int result = testClass.bankAccount(01234, 50);return BankTestOracle.bankAccount(result);}
    public static boolean test26() {Bank testClass = new Bank();int result = testClass.bankAccount(01234, 50);return BankTestOracle.bankAccount(result);}
    public static boolean test27() {Bank testClass = new Bank();int result = testClass.bankAccount(01234, 50);return BankTestOracle.bankAccount(result);}
    public static boolean test28() {Bank testClass = new Bank();int result = testClass.bankAccount(01234, 50);return BankTestOracle.bankAccount(result);}
    public static boolean test29() {Bank testClass = new Bank();int result = testClass.bankAccount(01234, 50);return BankTestOracle.bankAccount(result);}
    public static boolean test30() {Bank testClass = new Bank();int result = testClass.bankAccount(01234, 50);return BankTestOracle.bankAccount(result);}
    public static boolean test31() {Bank testClass = new Bank();int result = testClass.bankAccount(01234, 50);return BankTestOracle.bankAccount(result);}

}