/*
Oracle tester java file
zo
*/

public	class	BankTestOracle	{
    static int i = 0;
    public	static	boolean	bankAccount(int result){
        int results[] = {   70,30,50,70,50,50,
                            60,60,60,50,40,
                            40,40,60,40,70,
                            70,70,70,70,70,
                            60,40,50,50,60,
                            40,50,50,50,50,
                            100000};
        BankTestDriver.totalTests++;
        if (result == results[i++]){
            return true;
        }
        else {return false;}
    }
}