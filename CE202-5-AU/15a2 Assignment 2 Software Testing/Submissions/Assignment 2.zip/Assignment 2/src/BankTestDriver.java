import java.io.InputStream;

public class BankTestDriver {
    private InputStream systemIn;

    public BankTestDriver(){
        this(System.in);
    }
    public BankTestDriver(InputStream in){
        systemIn = in;
    }
    /**
     * Main function calculating the POFOD on the basis of the return statement
     * results of all test cases
     * POFOD is being printed out
     */
    public static void main(String[] args) {
        //insert your code to execute your tests here
        //you should implement each test as a separate method below which
        //returns a Boolean value indicating whether the test is successful or not
        //to calculate the POFOD you will need to keep a count of the total
        //number of tests and the number of successful tests
        //<insert your code here>
        test1();
        System.out.println("POFOD is : "); //output your POFOD
    }

    /**
     * test case implementations
     * return boolean variables which indicate how successful the cases are
     */
    public static boolean test1() {
        Bank testClass = new Bank();
        testClass.bankAccount(01234, 50);
        InputStream meow = 4
        BankTestDriver newTester = BankTestDriver(InputStream );
        /*code to setup the variables and execute the test case 1
        your code will create an instance of the Bank class and execute the
        bankAccount method here
        you should then pass the output from the Bank test to the Oracle which
        will compare the output with the expected output and return a Boolean value
        indicating success or failure
        <insert your code here>*/
        //return BankTestOracle.bankAccount(/*<insert your parameters>*/);
        return false;
    }

    public static boolean test2() {
    //etc
    return false;
    }
}