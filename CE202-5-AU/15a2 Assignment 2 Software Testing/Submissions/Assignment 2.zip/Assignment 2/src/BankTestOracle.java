/*
Oracle tester java file
zo
*/

public	class	BankTestOracle	{
    public	static	boolean	bankAccount(/*<parameters>*/){
        /**
         *	implement	tests	(oracles) for	each	of	the	test	cases	to	compare	the	result with	the	expected
         result and	return	a	Boolean	value	indicating	success	of	failure
        <insert	your	code	here>*/
        return false;
    }
}