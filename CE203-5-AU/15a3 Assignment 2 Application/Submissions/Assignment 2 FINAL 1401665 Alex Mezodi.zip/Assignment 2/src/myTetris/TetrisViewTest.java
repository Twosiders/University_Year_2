package myTetris;

// code copied from Simon Lucas
// code copied by Udo Kruschwitz


import utilities.JEasyFrame;


public class TetrisViewTest {


    public static void main(String[] args) {
        // test the view component

        int w = 10;
        int h = 20;
        int[][] a = new int[w][h];

//        for (int i = 0; i < w; i++) {
//            a[i][19] = 14;
//            a[i][18] = 14;
//            a[i][17] = 14;
//        }
//        a[5][17] = 0;
//        a[4][17] = 0;
//        a[5][18] = 0;
//        a[4][18] = 0;

//        Random r = new Random();
//        for (int i = 0; i < w; i++) {
//            for (int j = h/2; j < h; j++) {
//                a[i][j] =
//                        r.nextInt(15-8) + 8;
//            }
//        }
        TetrisView tv = new TetrisView(a);
        new JEasyFrame(tv, "Alex Mezodi (1401665)'s Tetris Adventure");
    }
}