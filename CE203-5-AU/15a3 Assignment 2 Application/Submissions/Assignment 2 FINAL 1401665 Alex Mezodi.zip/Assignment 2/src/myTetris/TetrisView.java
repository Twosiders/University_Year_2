package myTetris;
import utilities.*;

// code copied from Simon Lucas
// code copied by Udo Kruschwitz


import com.sun.scenario.effect.impl.sw.sse.SSEBlend_SRC_OUTPeer;
import utilities.JEasyFrame;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;
// import all the Colors
import static java.awt.Color.*;

public class TetrisView extends JComponent implements MouseListener {
    //I expanded the colors array
    //When the block hits something and stops, it turns to a darker color
    static Color[] colors =
            // 0            1                2               3                   4               5                   6               7
            {black, green.brighter(), blue.brighter(), red.brighter(), yellow.brighter(), magenta.brighter(), pink.brighter(), cyan.brighter(),
            //                          8             9             10              11              12              13              14
                                green.darker(), blue.darker(), red.darker(), yellow.darker(), magenta.darker(), pink.darker(), cyan.darker()};
    int[][] a;
    int w, h;
    static int size = 30; //size of blocks
    boolean game_going = false;
    int time_interval = 100; //time interval
    boolean active = true; //if the block is falling or not
    boolean DidNotMove = false; //check if the block moved when it spawned. If not game over.
    Shape newShape = new Shape(); //create new shape initially
    JPanel keyMasterOverlord = new JPanel(); //dummy Jpanel for mouseListener
    int stage = 1;

    //Create a new board with length, timer, shape, dummy jpnael and mouselistener
    public TetrisView(int[][] a) {
        this.a = a;
        w = a.length;
        h = a[0].length;
        game_going = true;
        startTimer();
        newShape.createShape();
        newShape.printShape();
        keyMasterOverlord.addMouseListener(this);
        addMouseListener(this);
    }


    public void paintComponent(Graphics g) {
        // a[6][10] = 3;
        for (int i = 0; i < w; i++) {
            for (int j = 0; j < h; j++) {
                g.setColor(colors[a[i][j]]);
                g.fill3DRect(i * size, j * size,
                        size, size, true);
            }
        }
    }

    //if shape is not active create new one
    //otherwise move it down
    public void nextMove(){
            if(!active){
                active = true;
                newShape.createShape();
                newShape.printShape();
            }
        newShape.moveDown();
    }

    // move currently active block at fixed intervals:
    public void startTimer() {
        Timer timer = new Timer();
        TimerTask task = new TimerTask() {
            public void run() {
                if (game_going) {
                    nextMove();
                    repaint();
                }
            }
        };
        timer.scheduleAtFixedRate(task, 0, time_interval);
    }


    public Dimension getPreferredSize() {
        return new Dimension(w * size, h * size);
    }

    //mouse events left, right and middle.
    //most mouseevents are unused but we have to implement them
    public void mouseReleased(MouseEvent e) {}
    public void mouseEntered(MouseEvent e) {}
    public void mouseExited(MouseEvent e) {}
    public void mouseClicked(MouseEvent e) {}
    public void mousePressed(MouseEvent e) {
        if(active) {
            if (SwingUtilities.isLeftMouseButton(e)) {
                newShape.moveLeft();
            } else if (SwingUtilities.isRightMouseButton(e)) {
                newShape.moveRight();
            } else if (SwingUtilities.isMiddleMouseButton(e)){
                newShape.rotateShape();
            }
        }
    }
/*--------------------------------SHAPE-----------------------------------------*/
    //shape has a posTable where we get the initial positions from.
    //pos is the current position of the shape, which we update constantly
    public class Shape {
        int[][] pos;
        int posTable[][][] = new int[][][]{
                        {{3, 0, 1}, {4, 0, 1}, {4, 1, 1}, {5, 1, 1}}, //GREEN
                        {{3, 0, 2}, {4, 0, 2}, {5, 0, 2}, {4, 1, 2}}, //BLUE
                        {{3, 0, 3}, {4, 0, 3}, {5, 0, 3}, {6, 0, 3}}, //RED
                        {{3, 1, 4}, {4, 1, 4}, {4, 0, 4}, {5, 0, 4}}, //YELLOW
                        {{3, 0, 5}, {4, 0, 5}, {5, 0, 5}, {3, 1, 5}}, //MAGENTA
                        {{3, 0, 6}, {4, 0, 6}, {5, 0, 6}, {5, 1, 6}}, //PINK
                        {{4, 0, 7}, {5, 0, 7}, {4, 1, 7}, {5, 1, 7}}, //CYAN
                        };
        //at the beginning of the game initialize a random number which picks a shape
        //boolean fullLine checks if the line is full or not
        //int[] fullLine is a binary array which stores full lines as 1, and non fulls as 0
        Random r = new Random();
        int randomShape = Math.abs(r.nextInt()) % 7;
        boolean fullLine;
        int[] fullLines = {0,0,0,0,0,0,0,0,0,0,
                           0,0,0,0,0,0,0,0,0,0};

        public Shape() {

            this.pos = new int[4][3];
        }

        public void createShape() {
            stage = 1;
            //check if Shape moved at all, if it didn't end game
            //moveDown() sets DidNotMove = false if successfully moved
            if(DidNotMove == true) {
                game_going = false;
                System.out.println("Game Over");
            }
            DidNotMove = true;

            //otherwise create new random and pick another shape from list
            r = new Random();
            randomShape = Math.abs(r.nextInt()) % 7;
            for (int i = 0; i < 4; i++) {
                for(int k = 0; k < 3; k++) {
                    pos[i][k] = posTable[randomShape][i][k];
                }
            }
        }

        public void rotateShape(){
            try {
                eraseShape();
                switch (randomShape) {
                    case 0: //GREEN
                        if (stage == 1) {
                            pos[0][0] = (pos[0][0]) + 2;
                            pos[0][1] = (pos[0][1]);
                            pos[1][0] = (pos[1][0]) + 1;
                            pos[1][1] = (pos[1][1]) + 1;

                            pos[2][0] = (pos[2][0]);
                            pos[2][1] = (pos[2][1]);
                            pos[3][0] = (pos[3][0]) - 1;
                            pos[3][1] = (pos[3][1]) + 1;
                            stage = 2;
                        } else if (stage == 2) {
                            pos[0][0] = (pos[0][0]) - 2;
                            pos[0][1] = (pos[0][1]);
                            pos[1][0] = (pos[1][0]) - 1;
                            pos[1][1] = (pos[1][1]) - 1;

                            pos[2][0] = (pos[2][0]);
                            pos[2][1] = (pos[2][1]);
                            pos[3][0] = (pos[3][0]) + 1;
                            pos[3][1] = (pos[3][1]) - 1;
                            stage = 1;
                        }
                        break;
                    case 1: //BLUE
                        if (stage == 1) {
                            pos[2][0] = (pos[2][0]) - 1;
                            pos[2][1] = (pos[2][1]) - 1;
                            stage = 2;
                        } else if (stage == 2) {
                            pos[3][0] = (pos[3][0]) + 1;
                            pos[3][1] = (pos[3][1]) - 1;
                            stage = 3;
                        }
                        else if (stage == 3) {
                            pos[0][0] = (pos[0][0]) + 1;
                            pos[0][1] = (pos[0][1]) + 1;
                            stage = 4;
                        }
                        else if (stage == 4) {
                            pos[2][0] = (pos[2][0]) - 1;
                            pos[2][1] = (pos[2][1]) + 1;
                            stage = 1;
                        }
                        break;
                    case 2: //RED
                        if (stage == 1) {
                            pos[0][0] = (pos[0][0]) + 1;
                            pos[0][1] = (pos[0][1]) - 2;
                            pos[1][0] = (pos[1][0]);
                            pos[1][1] = (pos[1][1]) - 1;

                            pos[2][0] = (pos[2][0]) - 1;
                            pos[2][1] = (pos[2][1]);
                            pos[3][0] = (pos[3][0]) - 2;
                            pos[3][1] = (pos[3][1]) + 1;
                            stage = 2;
                        } else if (stage == 2) {
                            pos[0][0] = (pos[0][0]) - 1;
                            pos[0][1] = (pos[0][1]) + 2;
                            pos[1][0] = (pos[1][0]);
                            pos[1][1] = (pos[1][1]) + 1;

                            pos[2][0] = (pos[2][0]) + 1;
                            pos[2][1] = (pos[2][1]);
                            pos[3][0] = (pos[3][0]) + 2;
                            pos[3][1] = (pos[3][1]) - 1;
                            stage = 1;
                        }
                        break;
                    case 3: //YELLOW
                        if (stage == 1) {
                            pos[0][0] = (pos[0][0]) + 1;
                            pos[0][1] = (pos[0][1]) - 1;
                            pos[1][0] = (pos[1][0]);
                            pos[1][1] = (pos[1][1]);

                            pos[2][0] = (pos[2][0]) + 1;
                            pos[2][1] = (pos[2][1]) + 1;
                            pos[3][0] = (pos[3][0]);
                            pos[3][1] = (pos[3][1]) + 2;
                            stage = 2;
                        } else if (stage == 2) {
                            pos[0][0] = (pos[0][0]) - 1;
                            pos[0][1] = (pos[0][1]) + 1;
                            pos[1][0] = (pos[1][0]);
                            pos[1][1] = (pos[1][1]);

                            pos[2][0] = (pos[2][0]) - 1;
                            pos[2][1] = (pos[2][1]) - 1;
                            pos[3][0] = (pos[3][0]);
                            pos[3][1] = (pos[3][1]) - 2;
                            stage = 1;
                        }
                        break;
                    case 4: //MAGENTA
                        if (stage == 1) {
                            pos[0][0] = (pos[0][0]) + 1;
                            pos[0][1] = (pos[0][1]) - 1;

                            pos[2][0] = (pos[2][0]) - 1;
                            pos[2][1] = (pos[2][1]) + 1;
                            pos[3][0] = (pos[3][0]);
                            pos[3][1] = (pos[3][1]) - 2;
                            stage = 2;
                        } else if (stage == 2) {
                            pos[0][0] = (pos[0][0]) + 1;
                            pos[0][1] = (pos[0][1]) + 1;

                            pos[2][0] = (pos[2][0]) - 1;
                            pos[2][1] = (pos[2][1]) - 1;
                            pos[3][0] = (pos[3][0]) + 2;
                            pos[3][1] = (pos[3][1]);
                            stage = 3;
                        } else if (stage == 3) {
                            pos[0][0] = (pos[0][0]) - 1;
                            pos[0][1] = (pos[0][1]) + 1;

                            pos[2][0] = (pos[2][0]) + 1;
                            pos[2][1] = (pos[2][1]) - 1;
                            pos[3][0] = (pos[3][0]);
                            pos[3][1] = (pos[3][1]) + 2;
                            stage = 1;
                        }
                        break;
                    case 5: //PINK
                        System.out.println("Sorry, rotation not implemented for this Shape");
                        break;
                    case 6: //CYAN
                        //square doesn't have to rotate
                        break;
                }
                printShape();
            }catch(IndexOutOfBoundsException e){
                System.out.println("Stop Spamming please!");
            }
        }

        //when we update the shape whenever it moves, we first erase it by turning all to black.
        public void eraseShape(){
            try {
                for (int i = 0; i < 4; i++) {
                    a[pos[i][0]][pos[i][1]] = 0;
                }
            } catch (IndexOutOfBoundsException e){
                System.out.println("Stop spamming please!");
            }
        }
        //erase line when it gets full
        //turn full line to black
        //shift all lines above the full line down
        public void eraseLine(int lineNum){
            //first of all erase that line
            for(int width = 0; width < w; width++){
                a[width][lineNum] = 0;
            }
                for(int height = lineNum-1; height>=0; height--) {
                    for (int width = w - 1; width >= 0; width--) {
                        a[width][height + 1] = a[width][height];
                        a[width][height] = 0;
                    }
                }

            JEasyFrame.incScore();
        }

        //we updated the position, now print it out again
        public void printShape() {
            for (int i = 0; i < 4; i++) {
                a[pos[i][0]][pos[i][1]] = pos[i][2];
            }
        }

        //move down the shape by 1 line
        //if at the very bottom, deactivate
        //if the next line down is not black or the same color as our shape, (so we hit a block) deactivate
        //some shapes obviously have overlapping blocks, so we check the same color.
        public void moveDown() {
            for (int i = 0; i < 4; i++) {
                if(a[pos[i][0]][19] == pos[i][2]) {
                    Inactivize();
                    return;
                }
                if(a[pos[i][0]][pos[i][1]+1] != 0)
                    if(a[pos[i][0]][pos[i][1]+1] != pos[i][2]) {
                        Inactivize();
                        return;
                    }
            }

            //erase, update position, reprint one level lower
            eraseShape();
            for (int i = 0; i < 4; i++) {
                pos[i][1] = pos[i][1]+1;
            }
            printShape();
            DidNotMove = false;
        }
        /*-----------------------------------------------*/
        public void moveLeft() {
            //if block is already at the very left, don't move
            //also if there is block next to our shape don't move it
            for (int i = 0; i < 4; i++) {
                if (a[0][pos[i][1]] == pos[i][2]) return;
                if (  a [pos[i][0]-1] [pos[i][1]] != 0  )
                    if (  a [pos[i][0]-1] [pos[i][1]] != pos[i][2]  ) return;
            }

            //erase, update position, reprint one level lower
            eraseShape();
            for (int i = 0; i < 4; i++) {
                pos[i][0] = pos[i][0] - 1;
            }
            printShape();
        }

        public void moveRight() {
            //exactly the same idea as moveLeft()
            //except we add +1 to the width cause we move right
            for (int i = 0; i < 4; i++) {
                if (a[w-1][pos[i][1]] == pos[i][2]) return;
                if (  a [pos[i][0]+1] [pos[i][1]] != 0  )
                    if (  a [pos[i][0]+1] [pos[i][1]] != pos[i][2]  ) return;
            }

            eraseShape();
            for (int i = 0; i < 4; i++) {
                pos[i][0] = pos[i][0] + 1;
            }
            printShape();
        }

        //first of all, deactivate shape and turn it a darker color
        public void Inactivize(){
            try {
                for (int i = 0; i < 4; i++) {
                    a[pos[i][0]][pos[i][1]] = pos[i][2] + 7;
                }
                active = false;
            } catch (IndexOutOfBoundsException e) {}

            //reset fullLines table
            for(int line = 0; line < fullLines.length; line++){
                fullLines[line] = 0;
            }

            //check if there are any full lines
            //first we check by height if there are any block on the far left
            //if yes we check the full lines of that height
            for (int i = 0; i < h; i++) {
                if(a[0][i] != 0) {
                    fullLines[i] = 1;
                    fullLine = true;
                    for (int p = 0; p < w; p++) {
                        if(a[p][i] == 0) {
                            fullLine = false;
                            fullLines[i] = 0;
                        }
                    }
                }
            }
            //erase bottom full lines first
            //fullLines {0,0,0,0,0,1,0,0,1} etc.    work from backwards of the list.
            for(int line = 0; line < fullLines.length; line++){
                if(fullLines[line] == 1) {
                    eraseLine(line);
                }
            }
        }
    }
}
