package utilities;

// code copied from Simon Lucas
// code copied by Udo Kruschwitz


import myTetris.TetrisView;

import javax.swing.*;
import java.awt.*;

public class JEasyFrame extends JFrame  {
    public Component comp;
    public static JLabel gameStatus;
    static int score = 0;

    public JEasyFrame(Component comp, String title) {
        super(title);

        gameStatus = new JLabel("Score: "+String.valueOf(score));
        add(gameStatus, BorderLayout.SOUTH); //for the score / pause


        this.comp = comp;
        getContentPane().add(BorderLayout.CENTER, comp); //frame screen thing

        pack(); //size frame to be at or above its preferred size
        this.setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        repaint();
    }

    public Component getComp(){
        return comp;
    }
    public static void incScore(){
        score = score + 10;
        gameStatus.setText("Score: "+String.valueOf(score));
    }
}
