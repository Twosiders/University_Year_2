package myTetris;
import utilities.JEasyFrame;
// code copied from Simon Lucas
// code copied by Udo Kruschwitz


import com.sun.scenario.effect.impl.sw.sse.SSEBlend_SRC_OUTPeer;
import utilities.JEasyFrame;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;
// import all the Colors
import static java.awt.Color.*;

public class TetrisView extends JComponent implements MouseListener {
    static Color[] colors =
            // 0            1                2               3                   4               5                   6               7
            {black, green.brighter(), blue.brighter(), red.brighter(), yellow.brighter(), magenta.brighter(), pink.brighter(), cyan.brighter(),
            //                          8             9             10              11              12              13              14
                                green.darker(), blue.darker(), red.darker(), yellow.darker(), magenta.darker(), pink.darker(), cyan.darker()};
    int[][] a;
    int w, h;
    static int size = 30;
    boolean game_going = false;
    int time_interval = 100;
    boolean active = true;
    boolean DidNotMove = false;
    Shape newShape = new Shape();
    JPanel keyMasterOverlord = new JPanel();
    boolean lineDeleted = false;


    public TetrisView(int[][] a) {
        this.a = a;
        w = a.length;
        h = a[0].length;
        game_going = true;
        startTimer();
        newShape.createShape();
        newShape.printShape();
        keyMasterOverlord.addMouseListener(this);
        addMouseListener(this);
    }


    public void paintComponent(Graphics g) {
        // a[6][10] = 3;
        for (int i = 0; i < w; i++) {
            for (int j = 0; j < h; j++) {
                g.setColor(colors[a[i][j]]);
                g.fill3DRect(i * size, j * size,
                        size, size, true);
            }
        }
    }


    public void nextMove(){
            if(!active){
                active = true;
                newShape.createShape();
                newShape.printShape();
            }
        newShape.moveDown();
    }

    // move currently active block at fixed intervals:
    public void startTimer() {
        Timer timer = new Timer();
        TimerTask task = new TimerTask() {
            public void run() {
                if (game_going) {
                    nextMove();
                    repaint();
                }
            }
        };
        timer.scheduleAtFixedRate(task, 0, time_interval);
    }


    public Dimension getPreferredSize() {
        return new Dimension(w * size, h * size);
    }

    public void mouseReleased(MouseEvent e) {}
    public void mouseEntered(MouseEvent e) {}
    public void mouseExited(MouseEvent e) {}
    public void mouseClicked(MouseEvent e) {}
    public void mousePressed(MouseEvent e) {
        if(active) {
            if (SwingUtilities.isLeftMouseButton(e)) {
                newShape.moveLeft();
            } else if (SwingUtilities.isRightMouseButton(e)) {
                newShape.moveRight();
            }
        }
    }

/*--------------------------------SHAPE-----------------------------------------*/
    public class Shape {
        int[][] pos;
        int posTable[][][] = new int[][][]{
                        {{3, 0, 1}, {4, 0, 1}, {4, 1, 1}, {5, 1, 1}}, //GREEN
                        {{3, 0, 2}, {4, 0, 2}, {5, 0, 2}, {4, 1, 2}}, //BLUE
                        {{3, 0, 3}, {4, 0, 3}, {5, 0, 3}, {6, 0, 3}}, //RED
                        {{3, 1, 4}, {4, 1, 4}, {4, 0, 4}, {5, 0, 4}}, //YELLOW
                        {{3, 0, 5}, {4, 0, 5}, {5, 0, 5}, {3, 1, 5}}, //MAGENTA
                        {{3, 0, 6}, {4, 0, 6}, {5, 0, 6}, {5, 1, 6}}, //PINK
                        {{4, 0, 7}, {5, 0, 7}, {4, 1, 7}, {5, 1, 7}}};//CYAN
        Random r = new Random();
        int randomShape = Math.abs(r.nextInt()) % 7;
        boolean fullLine;
        int[] fullLines = {0,0,0,0,0,0,0,0,0,0,
                           0,0,0,0,0,0,0,0,0,0};
        public Shape() {

            this.pos = new int[4][3];
        }

        public void createShape() {
            //check if Shape moved at all, if it didn't end game
            //moveDown() sets DidNotMove = false if successfully moved
            if(DidNotMove == true) {
                game_going = false;
                System.out.println("Game Over");
            }
            DidNotMove = true;

            r = new Random();
            randomShape = 6;
            for (int i = 0; i < 4; i++) {
                for(int k = 0; k < 3; k++) {
                    pos[i][k] = posTable[randomShape][i][k];
                }
            }
        }

        public void eraseShape(){
            for (int i = 0; i < 4; i++) {
                a[pos[i][0]][pos[i][1]] = 0;
            }
        }
        /*HERE HERE HERE----------------------------------*/
        public void eraseLine(int lineNum){
            //first of all erase that line
            for(int width = 0; width < w; width++){
                a[width][lineNum] = 0;
            }
            System.out.println(lineNum);
            for(int height = lineNum-1; height>0; height--) {
                for (int width = w - 1; width > 0; width--) {
                    a[width][height + 1] = a[width][height];
                    a[width][height] = 0;
                    System.out.println("a["+width+"]["+height+"]");
                }
            }

        }

        public void printShape() {
            for (int i = 0; i < 4; i++) {
                a[pos[i][0]][pos[i][1]] = pos[i][2];
            }
        }
        /*-----------------------------------------------*/
        public void moveDown() {
            //if it's possible, erase shape + reprint
            for (int i = 0; i < 4; i++) {
                if(a[pos[i][0]][19] == pos[i][2]) {
                    Inactivize();
                    return;
                }
                if(a[pos[i][0]][pos[i][1]+1] != 0)
                    if(a[pos[i][0]][pos[i][1]+1] != pos[i][2]) {
                        Inactivize();
                        return;
                    }
            }

            //erase, update position, reprint one level lower
            eraseShape();
            for (int i = 0; i < 4; i++) {
                pos[i][1] = pos[i][1]+1;
            }
            printShape();
            DidNotMove = false;
        }
        /*-----------------------------------------------*/
        public void moveLeft() {
            //if block is already at the very left, don't move

            for (int i = 0; i < 4; i++) {
                if (a[0][pos[i][1]] == pos[i][2]) return;
                if (  a [pos[i][0]-1] [pos[i][1]] != 0  )
                    if (  a [pos[i][0]-1] [pos[i][1]] != pos[i][2]  ) return;
            }

            eraseShape();
            for (int i = 0; i < 4; i++) {
                pos[i][0] = pos[i][0] - 1;
            }
            printShape();
        }

        public void moveRight() {
            for (int i = 0; i < 4; i++) {
                if (a[w-1][pos[i][1]] == pos[i][2]) return;
                if (  a [pos[i][0]+1] [pos[i][1]] != 0  )
                    if (  a [pos[i][0]+1] [pos[i][1]] != pos[i][2]  ) return;
            }

            eraseShape();
            for (int i = 0; i < 4; i++) {
                pos[i][0] = pos[i][0] + 1;
            }
            printShape();
        }

        public void rotateShape() {
            for (int i = 0; i < 4; i++) {
                pos[i][0] = pos[i][0] * cos(45) - pos[i][1] * sin(45);
            }
        }

        public void Inactivize(){
            try {
                for (int i = 0; i < 4; i++) {
                    a[pos[i][0]][pos[i][1]] = pos[i][2] + 7;
                }
                active = false;
            } catch (IndexOutOfBoundsException e) {}

            for(int line = 0; line < fullLines.length; line++){
                fullLines[line] = 0;
            }

            for (int i = 0; i < h; i++) {     //This runs 10x <--->
                if(a[0][i] != 0) {
                    fullLines[i] = 1;
                    fullLine = true;
                    for (int p = 0; p < w; p++) {               //This runs 20x ^^
                        if(a[p][i] == 0) {
                            fullLine = false;
                            fullLines[i] = 0;
                        }
                    }
                }
            }
            //fullLines {0,0,0,0,0,1,0,0,1} etc.    work from backwards of the list.
            for(int line = fullLines.length-1; line > 0; line--){
                if(fullLines[line] == 1) {
                    eraseLine(line);
                }
            }
        }
    }
}
