import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Created by amezod on 25/10/2015.
 */
public class CE203_2015_Ex1 extends JApplet {
    JTextField red;
    JTextField green;
    JTextField blue;
    JTextField myLabel;
    Color myColor = Color.green;

    public void init(){
        JPanel northPanel = new JPanel();
        JPanel centerPanel = new JPanel();
        JPanel southPanel = new JPanel();
        add(northPanel, BorderLayout.NORTH);
        add(centerPanel, BorderLayout.CENTER);
        add(southPanel, BorderLayout.SOUTH);

        red = new JTextField(3);
        green = new JTextField(3);
        blue = new JTextField(3);
        myLabel = new JTextField(35);

        myLabel.setText("Welcome to CE203 Assignment 1,\n" + "submitted by: Alex Mezodi 1401665");
        myLabel.setEditable(false);
        myLabel.setForeground(myColor);

        northPanel.add(red);
        northPanel.add(green);
        northPanel.add(blue);
        centerPanel.add(myLabel);

        JButton butGo = new JButton("GO!");
        northPanel.add(butGo);
        butGo.addActionListener(new ButtonHandler(this,1));

        JButton butReset = new JButton("Reset");
        southPanel.add(butReset);
        butReset.addActionListener(new ButtonHandler(this,2));

    }
}
class ButtonHandler implements ActionListener {
    CE203_2015_Ex1 theApplet;
    int theOp;

    public ButtonHandler(CE203_2015_Ex1 theApplet, int myOp) {
        this.theApplet = theApplet;
        theOp = myOp;
    }

    public void actionPerformed(ActionEvent e) {
        try {
            switch (theOp) {
                case 1:
                    theApplet.myLabel.setText("Welcome to CE203 Assignment 1,\n" + "submitted by: Alex Mezodi 1401665");
                    String redText = theApplet.red.getText();
                    String greenText = theApplet.green.getText();
                    String blueText = theApplet.blue.getText();

                    int redInt = Integer.parseInt(redText);
                    int greenInt = Integer.parseInt(greenText);
                    int blueInt = Integer.parseInt(blueText);

                    if (redInt < 0) {
                        redInt = 150;
                        theApplet.red.setText("150");
                    }
                    ;
                    if (greenInt < 0) {
                        greenInt = 150;
                        theApplet.green.setText("150");
                    }
                    ;
                    if (blueInt < 0) {
                        blueInt = 150;
                        theApplet.blue.setText("150");
                    }
                    ;

                    if (redInt > 255) {
                        redInt = 255;
                        theApplet.red.setText("255");
                    }
                    ;
                    if (greenInt > 255) {
                        greenInt = 255;
                        theApplet.green.setText("255");
                    }
                    ;
                    if (blueInt > 255) {
                        blueInt = 255;
                        theApplet.blue.setText("255");
                    }
                    ;

                    theApplet.myColor = new Color(redInt, greenInt, blueInt);
                    theApplet.myLabel.setForeground(theApplet.myColor);
                    break;
                case 2:
                    theApplet.myLabel.setText("Welcome to CE203 Assignment 1,\n" + "submitted by: Alex Mezodi 1401665");
                    theApplet.myColor = Color.green;
                    theApplet.myLabel.setForeground(theApplet.myColor);
                    theApplet.red.setText("");
                    theApplet.green.setText("");
                    theApplet.blue.setText("");
                    break;
            }

        }
        catch(Exception error){
            theApplet.myLabel.setText("Invalid Input.");
        }
    }
}
