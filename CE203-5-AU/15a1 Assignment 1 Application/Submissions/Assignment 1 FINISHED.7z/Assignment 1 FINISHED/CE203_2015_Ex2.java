import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.util.*;

/**
 * Created by Alexander on 27/10/2015.
 */
public class CE203_2015_Ex2 extends JApplet {

    JPanel inPanel = new JPanel();
    JPanel outPanel = new JPanel();

    JButton butAdd = new JButton("Add new item to list");
    JButton butChar = new JButton("Search by Character");
    JButton butWord = new JButton("Search by Word");
    JButton butFirst = new JButton("Remove first occurance");
    JButton butAll = new JButton("Remove all occurances");
    JButton butClear = new JButton("Clear all elements");

    JLabel outLabel = new JLabel("Name: Alex Mezodi Reg: 1401665", JLabel.CENTER);
    JTextField inText = new JTextField(20);

    LinkedList<String> magicList = new LinkedList<String>();

    public void init(){
        GridLayout experimentLayout = new GridLayout(0,2);
        JPanel butPanel = new JPanel();
        butPanel.setBackground(Color.darkGray);
        butPanel.setSize(200,200);

        add(inPanel, BorderLayout.NORTH);
        add(outPanel, BorderLayout.CENTER);
        add(butPanel, BorderLayout.SOUTH);
        butPanel.setLayout(experimentLayout);

        outPanel.add(outLabel);
        inPanel.add(inText);

        butPanel.add(butAdd);
        butAdd.addActionListener(new ButtonHandler2(this,1));
        butPanel.add(butChar);
        butChar.addActionListener(new ButtonHandler2(this,2));
        butPanel.add(butWord);
        butWord.addActionListener(new ButtonHandler2(this,3));
        butPanel.add(butFirst);
        butFirst.addActionListener(new ButtonHandler2(this,4));
        butPanel.add(butAll);
        butAll.addActionListener(new ButtonHandler2(this,5));
        butPanel.add(butClear);
        butClear.addActionListener(new ButtonHandler2(this,6));

        /*------------GUI Things End------------*/

    }
}
class ButtonHandler2 extends JPanel implements ActionListener {
    CE203_2015_Ex2 theApplet;
    int theOp;

    ButtonHandler2(CE203_2015_Ex2 app, int myOp){
        this.theApplet = app;
        theOp = myOp;
    }
    public void actionPerformed(ActionEvent e) {
        try{
            switch(theOp){
                case 1:
//                    if(theApplet.inText.getText().contains("-")) {
//                        theApplet.outLabel.setText("The word '"+theApplet.inText.getText()+"' is not a valid word.");
                    CharSequence seq = theApplet.inText.getText();
                    int len = seq.length();
                    for(int i=0; i<len; i++) {
                        char c = seq.charAt(i);

                        theApplet.outLabel.setText("The word '"+theApplet.inText.getText()+"' is not a valid word.");
                    }
                        theApplet.magicList.add(theApplet.inText.getText());
                        theApplet.outLabel.setText("The word: '" + theApplet.inText.getText() + "' has been added to the list.");
                    break;
                case 2:
                    String temp;
                    ArrayList results = new ArrayList();
                    for(int i=0; i<theApplet.magicList.size();i++){
                        temp = theApplet.magicList.get(i);
                        if(temp.toLowerCase().contains((theApplet.inText.getText().toLowerCase()).substring(0, 1))) {
                            results.add(temp);
                        };
                    }
                    theApplet.outLabel.setText("The word(s) " + results + " contain(s) the character '" + (theApplet.inText.getText()).substring(0, 1) +"'");
                    break;
                case 3:
//                    Set<String> magicHashList = new HashSet<String>(theApplet.magicList);
                    if(theApplet.inText.getText().isEmpty()){
//                        for (String key : magicHashList) {
//                            System.out.println(key + ": " + Collections.frequency(theApplet.magicList, key));
//                        }
                        //Some naughty code for displaying the number of EACH AND EVERY word on the list
                        theApplet.outLabel.setText("The list contains "+theApplet.magicList.size()+" words.");
                    } else {
                        int counter= 0;
                        for(int i=0; i<theApplet.magicList.size(); i++) {
                            if(theApplet.magicList.get(i).equals(theApplet.inText.getText())) counter++;
                        }
                        theApplet.outLabel.setText("The word: '"+theApplet.inText.getText()+"' was found "+counter+" many times in the list.");
                    }
                    break;
                case 4:
                    for(int i=0; i<theApplet.magicList.size(); i++) {
                        if(theApplet.magicList.get(i).equals(theApplet.inText.getText())) {
                            theApplet.outLabel.setText("The first occurance of the word: '"+theApplet.inText.getText()+"' has been removed from the list.");
                            theApplet.magicList.remove(i);
                            break;
                        } else {
                            theApplet.outLabel.setText("'"+theApplet.inText.getText()+"' was not found in the list.");
                        }
                    }
                    break;
                case 5:
                    for(int i=theApplet.magicList.size()-1; i>=0; i--) {
                        if(theApplet.magicList.get(i).equals(theApplet.inText.getText())) {
                            theApplet.outLabel.setText("All occurances of the word: '"+theApplet.inText.getText()+"' has been removed from the list.");
                            theApplet.magicList.remove(i);
                        } else {
                            theApplet.outLabel.setText("'"+theApplet.inText.getText()+"' was not found in the list.");
                        }
                    }
                    break;
                case 6:
                    theApplet.magicList.clear();
                    theApplet.outLabel.setText("The list has been cleared of all words.");
                    break;
            }

        } catch (Exception error){
            System.out.println(error);
        }
    }
}

