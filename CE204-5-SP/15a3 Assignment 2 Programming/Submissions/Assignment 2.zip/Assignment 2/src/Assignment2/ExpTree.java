package Assignment2;
import java.util.HashMap;
import java.util.Map;
/**
 * Created by Alexander on 11/03/2016.
 */
public class ExpTree {
    private int kind;
    private Object value;
    private ExpTree lChild, rChild;
    public static final int numNode = 0, idNode = 1, opNode = 2, letNode = 3, andNode = 4, equalsNode = 5;

    //static map so it can be returned in the recursive call
    //also boolean keeping note of tree type (normal vs. let)
    static Map myMap = new HashMap<>();
    static boolean let = false;

    public ExpTree(int knd, Object val, ExpTree l, ExpTree r) {
        kind = knd;
        value = val;
        lChild = l;
        rChild = r;
    }

    // methods to examine the node needed
    public void postOrder() {
    //if the leftChild or rightChild of the current node equals null, we have reached a leaf. Print out it's value
        if(kind!=3 &&lChild!=null)
            lChild.postOrder(); //first it goes down the left branch recursively
        if(rChild!=null) //after left branch is printed out the code continues to the right branch
            rChild.postOrder();
        if(kind!=3)
            System.out.print(value + " ");//aaand, after the right branch is finished the code continues to print out the original root
    }

    //Basically, same initial idea as PostOrder(), to run through the tree
    //but it searches for kind == 5, which is equal signs.
    //When it finds an equal sign it takes it's left child as ID
    //and evaluates the right child for the ID's value and save into map.
    public void makeTheMap(){
        if(lChild!=null){
            lChild.makeTheMap();
        }
        if(rChild!=null){
           rChild.makeTheMap();
        }
        if(kind==5){
            myMap.put(lChild.value,rChild.Evaluator());
        }
    }

    //Just a basic function to print a map for testing purposes.
    public void printTheMap(){
        System.out.println("\t"+myMap);
    }

    //toString method to print out values IN-ORDER
    public String toString() {
        String s1 = "";
        String s2 = "";
        //Gather all lefties from root
        if (lChild != null) { //definitely an operator node
            //rather long if statement. Checks for:
            //if current node is: % / * ^
            //if current node's leftie is - or +
            //not a 'let','and','equal' node
            if ((!value.equals('-') && !value.equals('+')) && (lChild.value.equals('-') || lChild.value.equals('+'))&& (kind!=3&& kind!=4&& kind!=5)) {
                s1 = "(" + lChild.toString() + ")";
            }
            //if current node is ^ and leftChild * /
            //not a 'let','and','equal' node
            else if ((value.equals('^'))&&(lChild.value.equals('*') || lChild.value.equals('/') || lChild.value.equals('%'))&& (kind!=3&& kind!=4&& kind!=5)) {
                s1 = "(" + lChild.toString() + ")";
            }
            //if node and it's left child are ^
            //not a 'let','and','equal' node
            else if((value.equals(('^'))) && (lChild.value.equals('^'))&& (kind!=3&& kind!=4&& kind!=5)){
                s1 = "(" + lChild.toString() + ")";
            }
            //else just don't do anything special. No brackets thank you very much!
            else {
                s1 = lChild.toString();
            }
        }
        //Gather all righties from root
        if (rChild != null) {
            //rather long if statement. Checks for:
            //if rightChild is - +
            //not a 'let','and','equal' node
            if ((rChild.value.equals('-') || rChild.value.equals('+'))&&(kind!=3 && kind!=4 && kind!=5)) {
                s2 = "(" + rChild.toString() + ")";
            }
            //if current node is not - + and rightChild is * / %
            //not a 'let','and','equal' node
            else if ((!value.equals('-') && !value.equals('+')) && (rChild.value.equals('*') || rChild.value.equals('/') || rChild.value.equals('%')) && kind!=3&& kind!=4&& kind!=5) {
                s2 = "(" + rChild.toString() + ")";
            }
            //else just don't do anything special. No brackets thank you very much!
            else {
                s2 = rChild.toString();
            }
        }

        //important part, as recursive calls keep concatenating with variable value
        //s1 is left side
        //s2 is right side.
        String result = s1+value+s2;
        return result;
    }

    //evaluate the value of operator nodes and return an int
    public int Evaluator(){
        int result = 0;
        if(kind==3){//if tree is let tree, only check the right side
            return rChild.Evaluator();
        }
        if(kind==0){//if number just return an int of value
            return result = (int)value;
        }
        if(kind==1 && !getLet()){//if not let tree, and is an identifier, return alphabetical number. A=0, B=1...Z=26
            char cval = (char)value;
            return result = (cval - 'A' + 1) - 1;
        }

        if(kind==1 && getLet()){//if let tree and operator, check the map for value.
            try {
                Object mapVal = myMap.get((char) value);
                return (int) mapVal;
            } catch (NullPointerException ex){ //if operator has not been set, throw error and return 0 stead of it.
                System.out.println(ex+": Identifier has not been set. Returning 0.");
                return 0;
            }
        }
        //if operator node, make recursive calls to children.
        //please note that rChild.rChild will never throw an error, as there are no operator leaf nodes.
        if(kind==2){
            if(lChild.lChild!=null)
                lChild.Evaluator();
            if(rChild.rChild!=null)
                rChild.Evaluator();
            //switch statement to check what operator it is
            //similar to parser.java switch
            switch((char)value) {
                case '+':
                    return lChild.Evaluator() + rChild.Evaluator();
                case '-':
                    return lChild.Evaluator() - rChild.Evaluator();
                case '*':
                    return lChild.Evaluator() * rChild.Evaluator();
                case '/':
                    if(rChild.Evaluator() < 1)
                        throw new ArithmeticException();
                    return lChild.Evaluator() / rChild.Evaluator();
                case '%':
                    return lChild.Evaluator() % rChild.Evaluator();
                case '^':
                    if(rChild.Evaluator() < 0)
                        throw new ArithmeticException();
                    return (int)Math.pow(lChild.Evaluator(),rChild.Evaluator());
            }

        }
        return 0;
    }

    //functions for returning if it's a let tree
    //and setter function for the boolean for that purpose
    public boolean getLet(){return let;}
    public void setLet(){
        if(kind==3)
            let = true;
        else
            let = false;
    }

}