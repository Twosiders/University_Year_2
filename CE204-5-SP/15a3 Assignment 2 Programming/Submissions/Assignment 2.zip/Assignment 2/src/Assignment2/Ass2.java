package Assignment2; /**
 * Created by Alexander on 12/03/2016.
 */
import java.util.Scanner;

public class Ass2 {

    /*-------------- For part6, I have stored the identifiers in 2 child nodes.
    //-PLEASE NOTE!- So, just as an example, I've included how a tree would
    //-------------- look like with the example expression in the assignment.
    //Expression : let A = 3^2 and B = 0-5 in (A+3)*(2+(A+B)/3);
                        [  let  ]
                   /                  \
                [and]                [ * ]
              [=]   [=]           [+]     [+]
            [A][^]  [B][-]      [A][3]  [2][/]
                |       |                   |
             [3][2]   [0][5]             [+][3]
                                           |
                                         [A][B]
    */

    public static void main(String[] args) {
        String choice = "y";
        System.out.println("Alex Mezodi 1401665");
        while (choice.equals("y")) {
            System.out.println("Thank you for using my expression evaluation program. Please type an expression:");
            ExpTree myTree = new Parser().parseLine();
            myTree.setLet(); //check if tree is a letTree
            System.out.println("Post Order:");
            myTree.postOrder();
            System.out.println("\nIn Order:");
            System.out.println(myTree);

            //fill the map with the values only if it's a Let tree
            if(myTree.getLet()){
                myTree.makeTheMap();
                //myTree.printTheMap(); printMap function in case
            }

            try {
                System.out.println("\nResult is: " + myTree.Evaluator());
            } catch(ArithmeticException|ParseException ex) {
                System.out.println("Division by Zero or Negative Power Operand. Terminating..");
                System.exit(1);
            }

            //ask user for another round ;)
            System.out.println("Would you like to input another expression? Type 'y' if yes.");
            Scanner user_input = new Scanner(System.in);
            choice = user_input.next();

        }
    }
}
