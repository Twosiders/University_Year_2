/**
 * Created by Alexander on 13/02/2016.
 */
public class DQTest extends DequeueList {
    public static void main(String args[]){
        DequeueList myList = new DequeueList();
        System.out.println(myList);
        myList.addLeft('c');
        myList.addLeft('b');
        myList.addLeft('a');
        myList.addRight('d');
        myList.addRight('e');
        myList.addRight('f');
        myList.addRight('g');
        System.out.println(myList);
        System.out.println("Left of the list is: " + myList.left());
        System.out.println("Right of the list is: " + myList.right());

        myList.removeLeft();
        System.out.println(myList);
        myList.removeRight();
        myList.removeRight();
        myList.removeRight();
        myList.removeRight();
        myList.removeRight();
        myList.removeRight();
        myList.removeRight();
        System.out.println(myList);

        System.out.println("List empty: "+myList.isEmpty());
    }
}
