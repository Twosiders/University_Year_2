

public class BST
{ private BTNode<Integer> root;

    public BST()
    { root = null;
    }

    public boolean find(Integer i)
    { BTNode<Integer> n = root;
        boolean found = false;

        while (n!=null && !found)
        { int comp = i.compareTo(n.data);
            if (comp==0)
                found = true;
            else if (comp<0)
                n = n.left;
            else
                n = n.right;
        }

        return found;
    }

    public boolean insert(Integer i)
    { BTNode<Integer> parent = root, child = root;
        boolean goneLeft = false;

        while (child!=null && i.compareTo(child.data)!=0)//integer and child not the same values
        { parent = child;
            if (i.compareTo(child.data)<0)
            {
                System.out.println(i+" is less than "+child.data);
                child = child.left;
                goneLeft = true;
            }
            else
            { child = child.right;
                goneLeft = false;
            }
        }

        if (child!=null)
            return false;  // number already present
        else
        { BTNode<Integer> leaf = new BTNode<Integer>(i);
            if (parent==null) // tree was empty
                root = leaf;
            else if (goneLeft)
                parent.left = leaf;
            else
                parent.right = leaf;
            return true;
        }
    }
    /*
    * ADD
    * - public int nonleaves(){} - which should return the # of non-lead nodes
    * - public int depth(){} - which returns maximum depth of tree (root to deepest leaf)
    * - public int range(int min, int max) {} - return number of elements in range ie. "50 - 90"
    *
    * */

    private int nonleaves(BTNode n){
        int result = 1;
        if(n.left!=null && n.left.left != null) result += nonleaves(n.left);
        if(n.right!=null && n.right.right != null) result += nonleaves(n.right);
        return result;
    }
    public int nonleaves(){
        return(root == null) ? 0: nonleaves(root);
    }
    private int depth(BTNode n){
        if (n == null){
            return 0;
        }
        int left = depth(n.left);
        int right = depth(n.right);

        return Math.max(left,right)+1;
    }
    public int depth(){
        return(root == null) ? 0: depth(root);
    }

    // toString method for class BTree<T>
    public String toString()
    { return getString(root);
    }
    private static <T> String getString(BTNode<T> n) {
        if (n==null) {
            return "";
        }
        else
        { String s1 = getString(n.left);
            String s2 = getString(n.right);
            return s1+" "+n.data+" "+s2;
        }
    }
    public void range(int lower, int upper) {
        if(lower > upper)
            throw new IllegalArgumentException("lower is higher than upper");
        if(root != null)
            range(root,lower,upper);
    }
    private static void range(BTNode<Integer> root, int lower, int upper){
        BTNode<Integer> n = root;
        BTNode leftChild = n.left;
        BTNode rightChild = n.right;

        if(n.data >= lower && n.data <= upper) {
            System.out.println(n.data + " ");
        }
        if(leftChild != null && n.data > lower) {
            n = leftChild;
            range(n, lower, upper);
        }
        if(rightChild != null && n.data < upper){
            n = rightChild;
            range(n, lower, upper);
        }
    }
}

class BTNode<T> {
    T data;
    BTNode<T> left, right;

    BTNode(T o) {
        data = o; left = right = null;
    }
    public static void main(String args[]){
        BST myBST = new BST();
        myBST.insert(90);
        myBST.insert(50);
        myBST.insert(150);
        myBST.insert(75);
        myBST.insert(125);
        myBST.insert(170);
        myBST.insert(20);
        myBST.insert(15);
        myBST.insert(25);
        System.out.println(myBST.toString());
        System.out.println("Number of nonleaves: "+myBST.nonleaves());
        System.out.println("Depth of Tree: "+myBST.depth());
        myBST.range(25,200);
    }
}