import javafx.scene.control.ListCell;

/**
 * Created by Alexander on 08/02/2016.
 */

class DequeueCell<T> {
    char data;
    DequeueCell<T> next;
    private T t;

    public DequeueCell(char x, DequeueCell<T> c) {
        data = x;
        next = c;
    }
    /*
    IMPLEMENT
        - createdeq (don't implement this, will be the constructor)
        - isempty
        - left (Ex if empty)
        - right (Ex if empty)
        - addleft
        - addright
        - removeleft (Ex if empty)
        - removeright (Ex if empty)
    Constructor which creates new empty queues.
    toString(); method in the form <3,5,7>
    data in class must be Private.
    Add test-code* to main in separate class and file
    */

}
/*
* QueueException class
* */
class QueueException extends RuntimeException{
    public QueueException(String s){
        super(s);
    }
}
public class DequeueList {

    private DequeueCell front;

    public DequeueList() {
        front = null;
    }
    /*
    * isEmpty simply checks if the front
    * is empty or not.
    * */
    boolean isEmpty(){
        DequeueCell c = front;
        if(c == null)
            return true;
        return false;
    }
    public char elementAt(int n)
    { DequeueCell c = front;
        if (n<0)
            throw new QueueException("elementAt called with negative argument");
        for (int i = 0; i<n; i++)
        { if (c == null)
            throw new QueueException("no element at position "+n);
            c = c.next;
        }
        if (c == null)
            throw new QueueException("no element at position "+n);
        return c.data;
    }
    /*
    * addLeft just creates a new cell at the front
    * addRight checks if it's an only element list
    * in which case it's the same as addLeft.
    * Otherwise it goes through the list until the
    * next element is not null, and creates a new cell
    * at the end of the list.
    * */
    public void addLeft(char x){
        front = new DequeueCell(x, front);
    }
    public void addRight(char x)  {
        if (front==null)
            front = new DequeueCell(x, front);
        else
        { DequeueCell c = front;
            while (c.next != null)
                c = c.next;
            c.next = new DequeueCell(x, null);
        }
    }
    /*
    * char empty is returned if an exception is thrown (if the list is empty)
    * otherwise it returns the elementAt the first position (0)
    * */
    public char left(){
        char empty = ' ';
        try {
            DequeueCell c = front;
            if (c == null)
                throw new QueueException("List is empty. Returning empty char");
            return elementAt(0);
        } catch (QueueException ex){
            System.out.println(ex);
        }
        return empty;
    }
    /*
    * same idea as left(), except right loops until the end of the list
    * and returns the last element's or cell's data
    * */
    public char right(){
        char empty = ' ';
        try {
            DequeueCell c = front;
            if (c == null)
                throw new QueueException("List is empty. Returning empty char");
            while (c.next != null)
                c = c.next;
            return c.data;
        } catch (QueueException ex){
            System.out.println(ex);
        }
        return empty;
    }
    /*
    * removeLeft continuously goes through the list
    * re-shifting each member to the left, until the
    * last member becomes null of course, because the
    * element after that has no data.
    * */
    void removeLeft(){
        try {
            DequeueCell c = front;
            if (c == null)
                throw new QueueException("List is empty.");
            c.data = c.next.data;
            c.next = c.next.next;
            System.out.println("Removed left element.");
        } catch (QueueException ex){
            System.out.println(ex);
        }
    }
    /*
    * removeRight first of all does some error checking
    * then in the else clause it goes to the end of the list
    * but not the very end, the second last element
    * and basically nullifies the link between that
    * element and the last one, effectively deleting
    * the last element
    * */
    void removeRight(){
        try{
            DequeueCell c = front;
            if(c == null)
                throw new QueueException("List is empty.");
            if(c.next == null){
                front = null;
            } else {
                while (c.next.next != null)
                    c = c.next;
                c.next = null;
                System.out.println("Removed right element.");
            }
        } catch (QueueException ex){
            System.out.println(ex);
        }
    }

    public String toString()
    { StringBuffer sb = new StringBuffer("<");
        DequeueCell c = front;
        if(front != null){
            sb.append(front.data);
            c = c.next;
        }
        while (c != null)
        { sb.append(","+c.data);
            c = c.next;
        }
        return(sb+">");
    }
}

