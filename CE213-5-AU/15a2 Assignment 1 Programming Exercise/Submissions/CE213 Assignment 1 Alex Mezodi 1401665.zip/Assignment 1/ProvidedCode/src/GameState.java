import java.util.ArrayList;

/*
     Instances of the class GameState represent states that can arise in the sliding block puzzle.
 */

public class GameState {
    final char[] board;
    private int spacePos;
    static final char[] INITIAL_BOARD = {'B','B','B',' ','W','W','W'};
    static final char[] GOAL_BOARD = {'W','W','W',' ','B','B','B'};
    static final int BOARD_SIZE = 7;
        
    /*
        GameState is a constructor that takes a char array holding a board configuration as argument.
     */
    public GameState(char[] board) {
        this.board = board;
        for (int j = 0; j < BOARD_SIZE; j++){
            if (board[j] == ' ') {
                this.spacePos = j;
                break;
            }
        }
    }

    /*
        clone returns a new GameState with the same board configuration as the current GameState.
     */
    public GameState clone() {
        char[] clonedBoard = new char[BOARD_SIZE];
        System.arraycopy(this.board, 0, clonedBoard, 0, BOARD_SIZE);
        return new GameState(clonedBoard);
    }

    public int getSpacePos() {
        return spacePos;
    }

    /*
        toString returns the board configuration of the current GameState as a printable string.
    */
    public String toString() {
        String s = "[";
        for (char c : this.board) s = s + c;
        return s + "]";
    }

    /*
        isGoal returns true if and only if the board configuration of the current GameState is the goal
        configuration.
    */
    public boolean isGoal() {
        for (int j = 0; j < BOARD_SIZE; j++) {
            if (this.board[j] != GOAL_BOARD[j]) return false; //if any of the current node's elements don't equal the goal, return false
        }
        return true;
    }

    /*
         sameBoard returns true if and only if the GameState supplied as argument has the same board
         configuration as the current GameState.
     */
    public boolean sameBoard (GameState gs) {
        for (int j = 0; j < BOARD_SIZE; j++) {
            if (this.board[j] != gs.board[j]) return false;
        }
        return true;
    }

    /*
        possibleMoves returns a list of all GameStates that can be reached in a single move from the current GameState.
     */
    public ArrayList<GameState> possibleMoves() {
        ArrayList<GameState> moves = new ArrayList<GameState>();
        for (int start = 0; start < BOARD_SIZE; start++) {
            if (start != this.spacePos) {       //don't get exact same position
                int distance = Math.abs(this.spacePos - start); //distance is basically the distance tiles can jump.
                if (distance <= 3) {    //In the rules it says tiles can jump 2 over max, arrays start at 0 so we use 3 here
                    GameState newState = this.clone();
                    newState.board[this.spacePos] = this.board[start]; //so the way we check for a new state is literally just shifting the space between tiles. NOT THE B or W tiles!
                    //also this.spacePos is a temp variable for holding a value for the swap
                    newState.board[start] = ' '; //swap start position i.e. 'B' with ' '
                    newState.spacePos = start; //do the swap
                    moves.add(newState); //add this move we just generated to the list :)
                }
            }
        }
        return moves;
    }

}

